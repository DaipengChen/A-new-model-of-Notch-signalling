function dF=GetTwolocal(~,w,par)
L0=par(1);kd=par(2);beta=par(3);kt=par(4);kr=par(5);
kc=par(6);r2=par(7);N0=par(8);

dF=[L0-beta*w(1)-2*kd*w(1)^2-kr*w(1);
    kd*w(1)^2-kc*w(2)*w(3)-beta*w(2);
    N0-beta*w(3)-kc*w(2)*w(3)-kr*w(3);
    kr*w(1)-beta*w(4)-kt*w(11)*w(4);
    kr*w(3)-beta*w(5)-kt*w(10)*w(5);
    kt*w(10)*w(5)-r2*w(6);
    L0-beta*w(7)-2*kd*w(7)^2-kr*w(7);
    kd*w(7)^2-kc*w(8)*w(9)-beta*w(8);
    N0-beta*w(9)-kc*w(8)*w(9)-kr*w(9);
    kr*w(7)-beta*w(10)-kt*w(5)*w(10);
    kr*w(9)-beta*w(11)-kt*w(4)*w(11);
    kt*w(4)*w(11)-r2*w(12)];

end