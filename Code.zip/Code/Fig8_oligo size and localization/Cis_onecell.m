% This code is for simulating the notch acitivity with different expression
% level of internal ligands.
% Written by Daipeng Chen (26 July, 2021)

clc
clear
close all

%% Parameter setting
D0=200;kd=1*10^(-4);beta=0.1; %DLL4 monomer in cell %%%D0=0.3-0.5!!!!?
kt=5*10^(-5);kc=6*10^(-4); %trans-activation and cis-inhibition
r=0.5; %degradation rate of signaling of Notch and VEGF
N0=200; %production of Notch
par=[D0 kd beta kt kc r N0];
Lext=1500;

%% Initial condition
L=1000; %calculating period

%% Solving ODE by Runge-Kutta solver
for k = 1:101
    p1(k)=20*(k-1);
    par(1)= p1(k);
    [~,W1]=ode45(@ODEonecell,0:1:L,unifrnd(0,100,1,4),[],par,Lext,2);
    [~,W2]=ode45(@ODEonecell,0:1:L,unifrnd(0,100,1,4),[],par,Lext,3);
    [~,W3]=ode45(@ODEonecell,0:1:L,unifrnd(0,100,1,4),[],par,Lext,4);
    out1(k)=W1(end,4);
    out2(k)=W2(end,4);
    out3(k)=W3(end,4);
end

%% Output results
plot(p1,out1/max(out1),'LineWidth',3,'Color',[0.3,0.52,0.74])
hold on
plot(p1,out2/max(out2),'LineWidth',3,'Color',[0.97,0.56,0.24])
hold on
plot(p1,out3/max(out3),'LineWidth',3,'Color',[0.35,0.66,0.35])
axis([0 2000 0 1.1]);
legend('dimer','trimer','tetramer');
title('A cell exposed to fixed trans-ligand');
xlabel('Production rate of intracellular ligand (b_L)')
ylabel('NICD (normalized unit)')
set(gca,'FontSize',18)
