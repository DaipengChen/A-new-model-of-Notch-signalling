% This code is for simulating the notch acitivity with different expression
% level of internal ligands.
% Written by Daipeng Chen (26 July, 2021)

clc
clear
close all

%% Parameter setting
D0=200;kd=1*10^(-4);beta=0.1; %DLL4 monomer in cell
kt=5*10^(-6);kc=6*10^(-4); %trans-activation and cis-inhibition
r=0.5; %degradation rate of signaling of Notch and VEGF
N0=200; %production of Notch
kr=0.1; %from cytoplasm to membrane
par=[D0 kd beta kc kt kr r N0];

%% Initial condition
W0=unifrnd(0,100,1,4); %initial value of ODE
L=1000; %calculating period

%% Solving ODE by Runge-Kutta solver
p=logspace(0,4,50);
for k=1:length(p)
    par(1)=p(k);
    par(6)=0;
    [~,W1]=ode45(@ODECis,0:1:L,unifrnd(0,100,1,4),[],par,2);
    par(6)=kr;
    [~,W2]=ode45(@GetCislocal,0:1:L,unifrnd(0,100,1,6),[],par);
    out1(k)=W1(end,4);
    out2(k)=W2(end,6);
end

%% Output results
plot(p,out1,'LineWidth',3,'Color',[0.3,0.52,0.74])
hold on
plot(p,out2,'LineWidth',3,'Color',[0.97,0.56,0.24])
axis([1,10000,0 15])
legend('homogeneous','in cytoplasm','location','northwest');
title('An isolated cell (cis-activation)');
xlabel('Production rate of intracellular ligand (b_L)')
ylabel('Notch activity (NICD)')
set(gca,'FontSize',18)
set(gca, 'XScale', 'log')
