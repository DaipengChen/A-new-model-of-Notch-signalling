function dF=GetOnelocal(~,w,par,Lext)

% parmeters
D0=par(1);kd=par(2);beta=par(3);kt=par(4);kc=par(5);
r2=par(6);N0=par(7);kr=par(8);

%ode system
dF=[D0-beta*w(1)-2*kd*w(1)^2-kr*w(1);
    kd*w(1)^2-kc*w(3)*w(2)-beta*w(2);
    N0-beta*w(3)-kc*w(3)*w(2)-kr*w(3);
    kr*w(1)-beta*w(4);
    kr*w(3)-beta*w(5)-kt*Lext*w(5);
    kt*Lext*w(5)-r2*w(6)];

end