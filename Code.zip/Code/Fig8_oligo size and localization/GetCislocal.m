function dF=GetCislocal(~,w,par)

% parmeters
D0=par(1);kd=par(2);beta=par(3);kc=par(4);kt=par(5);
kr=par(6);r2=par(7);N0=par(8);

%ode system
dF=[D0-beta*w(1)-2*kd*w(1)^2-kr*w(1);
    kd*w(1)^2-kc*w(3)*w(2)-beta*w(2);
    N0-beta*w(3)-kc*w(3)*w(2)-kr*w(3);
    kr*w(1)-beta*w(4)-kt*w(5)*w(4);
    kr*w(3)-beta*w(5)-kt*w(4)*w(5);
    kt*w(4)*w(5)-r2*w(6)];

end