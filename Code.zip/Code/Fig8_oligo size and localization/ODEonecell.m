function dF=ODEonecell(~,w,par,Lext,n)

% parmeters
D0=par(1);kd=par(2);beta=par(3);kt=par(4);kc=par(5);
r=par(6);N0=par(7);

%ode system
dF=[D0-beta*w(1)-n*kd*w(1)^n;
    kd*w(1)^n-kc*w(3)*w(2)-beta*w(2);
    N0-beta*w(3)-kc*w(3)*w(2)-kt*Lext*w(3);
    kt*Lext*w(3)-r*w(4)];

end