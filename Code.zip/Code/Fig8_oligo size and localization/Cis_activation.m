% This code is for simulating the notch acitivity with different expression
% level of internal ligands.
% Written by Daipeng Chen (26 July, 2021)

clc
clear
close all

%% Parameter setting
D0=200;kd=1*10^(-4);beta=0.1; %DLL4 monomer in cell
kt=5*10^(-6);kc=6*10^(-4); %trans-activation and cis-inhibition
r=0.5; %degradation rate of signaling of Notch and VEGF
N0=200; %production of Notch
par=[D0 kd beta kc kt 0 r N0];

%% Initial condition
W0=unifrnd(0,100,1,4); %initial value of ODE
L=1000; %calculating period
size=2; %dimer

%% Solving ODE by Runge-Kutta solver
p=logspace(0,4,50);
for k=1:length(p)
    par(1)=p(k);
    [~,W1]=ode45(@ODECis,0:1:L,unifrnd(0,100,1,4),[],par,2);
    [~,W2]=ode45(@ODECis,0:1:L,unifrnd(0,100,1,4),[],par,3);
    [~,W3]=ode45(@ODECis,0:1:L,unifrnd(0,100,1,4),[],par,4);
    out1(k)=W1(end,4);
    out2(k)=W2(end,4);
    out3(k)=W3(end,4);
end

%% Output results
plot(p,out1/max(out1),'LineWidth',3,'Color',[0.3,0.52,0.74])
hold on
plot(p,out2/max(out2),'LineWidth',3,'Color',[0.97,0.56,0.24])
hold on
plot(p,out3/max(out3),'LineWidth',3,'Color',[0.35,0.66,0.35])
axis([1,10000,0 1.1])
legend('dimer','trimer','tetramer','location','northwest');
title('An isolated cell (cis-activation)');
xlabel('Production rate of intracellular ligand (b_L)')
ylabel('NICD (normalized unit)')
set(gca,'FontSize',18)
set(gca, 'XScale', 'log')
