function dF=ODEtwocells(~,w,par,n)
L0=par(1);kd=par(2);beta=par(3);kt=par(4);k3=par(5);
k4=par(6);r=par(7);N0=par(8);

dF=[L0-beta*w(1)-n*kd*w(1)^n-k3*w(3)*w(1)-kt*w(7)*w(1);
    kd*w(1)^n-k4*w(2)*w(3)-beta*w(2);
    N0-beta*w(3)-k3*w(1)*w(3)-k4*w(2)*w(3)-kt*w(5)*w(3);
    kt*w(5)*w(3)-r*w(4);
    L0-beta*w(5)-n*kd*w(5)^n-k3*w(7)*w(5)-kt*w(3)*w(5);
    kd*w(5)^n-k4*w(6)*w(7)-beta*w(6);
    N0-beta*w(7)-k3*w(5)*w(7)-k4*w(6)*w(7)-kt*w(1)*w(7);
    kt*w(1)*w(7)-r*w(8)];

end