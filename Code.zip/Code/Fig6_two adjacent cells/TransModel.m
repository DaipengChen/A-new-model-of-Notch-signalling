function dF=TransModel(~,w,par)
L0=par(1);kd=par(2);beta=par(3);k1=par(4);k2=par(5);
kc=par(6);r=par(7);N0=par(8);

dF=[L0-beta*w(1)-2*kd*w(1)^2-k1*w(7)*w(1);
    kd*w(1)^2-kc*w(2)*w(3)-beta*w(2)-k2*w(7)*w(2);
    N0-beta*w(3)-kc*w(2)*w(3)-k1*w(5)*w(3)-k2*w(6)*w(3);
    k1*w(5)*w(3)+k2*w(6)*w(3)-r*w(4);
    200-beta*w(5)-2*10^(-4)*w(5)^2-k1*w(3)*w(5);
    10^(-4)*w(5)^2-kc*w(6)*w(7)-beta*w(6)-k2*w(3)*w(6);
    N0-beta*w(7)-kc*w(6)*w(7)-k1*w(1)*w(7)-k2*w(2)*w(7);
    k1*w(1)*w(7)+k2*w(2)*w(7)-r*w(8)];

end