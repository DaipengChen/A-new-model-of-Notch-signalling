% This code is for simulating the notch acitivity with different expression
% level of internal ligands.
% Written by Daipeng Chen (26 July, 2021)

clc
clear
close all

%% Parameter setting
D0=200;kd=1*10^(-4);beta=0.1; %DLL4 monomer in cell
kt=5*10^(-5);kc=6*10^(-4); %trans-activation and cis-inhibition
r=0.5; %degradation rate of signaling of Notch and VEGF
N0=200; %production of Notch
par=[D0 kd beta kt kt kc r N0];

%% Initial condition
L=2000; %calculating period

%% Solving ODE by Runge-Kutta solver
for k = 1:101
    p1(k)=25*(k-1);
    par(1)= p1(k);
    par(4)=kt;par(5)=0;
    [~,W1]=ode45(@TransModel,0:1:L,unifrnd(0,100,1,8),[],par);
    par(4)=0;par(5)=kt;
    [~,W2]=ode45(@TransModel,0:1:L,unifrnd(0,100,1,8),[],par);
    par(4)=kt;par(5)=kt;
    [~,W3]=ode45(@TransModel,0:1:L,unifrnd(0,100,1,8),[],par);
    out1(k)=W1(end,8);
    out2(k)=W2(end,8);
    out3(k)=W3(end,8);
end

%% Output results
plot(p1,out1,'LineWidth',3,'Color',[0.3,0.52,0.74])
hold on
plot(p1,out2,'LineWidth',3,'Color',[0.97,0.56,0.24])
hold on
plot(p1,out3,'LineWidth',3,'Color',[0.35,0.66,0.35])
axis([0 2500 0 400]);
title('Trans-activation')
legend('Model T1','Model T2','Model T3','location','northwest');
xlabel('Production rate of trans-ligand (b_L)')
ylabel('Notch activity (NICD)')
set(gca,'FontSize',18)
