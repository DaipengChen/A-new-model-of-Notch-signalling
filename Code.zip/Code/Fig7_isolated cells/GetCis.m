function dF=GetCis(~,w,par,n)

% parmeters
D0=par(1);kd=par(2);beta=par(3);kc=par(4);k5=par(5);
k6=par(6);r=par(7);N0=par(8);

%ode system
dF=[D0-beta*w(1)-n*kd*w(1)^n-k5*w(1)*w(3);
    kd*w(1)^n-kc*w(3)*w(2)-k6*w(2)*w(3)-beta*w(2);
    N0-beta*w(3)-kc*w(3)*w(2)-k5*w(1)*w(3)-k6*w(2)*w(3);
    k5*w(1)*w(3)+k6*w(2)*w(3)-r*w(4)];

end