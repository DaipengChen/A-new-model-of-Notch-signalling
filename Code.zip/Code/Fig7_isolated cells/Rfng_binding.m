% This code is for simulating the notch acitivity with different expression
% level of internal ligands.
% Written by Daipeng Chen (26 July, 2021)

clc
clear
close all

%% Parameter setting
D0=200;kd=1*10^(-4);beta=0.1; %DLL4 monomer in cell
kt=5*10^(-6);kc=6*10^(-4); %trans-activation and cis-inhibition
r=0.5; %degradation rate of signaling of Notch and VEGF
N0=200; %production of Notch
par=[D0 kd beta kc kt 0 r N0];

%% Initial condition
W0=unifrnd(0,100,1,4); %initial value of ODE
L=1000; %calculating period
size=2; %dimer

%% Solving ODE by Runge-Kutta solver
p=logspace(0,4,50);kc=[10^(-6) 10^(-5) 10^(-4) 10^(-3)];
for j=1:length(p)
    par(1)=p(j);
    for i=1:4
        par(4)=kc(i);
        [~,W]=ode45(@GetCis,0:1:L,W0,[],par,size);
        X(i,j)=W(end,4);
    end
end

%% Output results
plot(p,X(1,:),'LineWidth',3,'Color',[0.6,0.6,0.6])
hold on
plot(p,X(2,:),'LineWidth',3,'Color',[0.4,0.4,0.4])
hold on
plot(p,X(3,:),'LineWidth',3,'Color',[0.2,0.2,0.2])
hold on
plot(p,X(4,:),'LineWidth',3,'Color',[0,0,0])
legend('k_{ci}=10^{-6}','k_{ci}=10^{-5}','k_{ci}=10^{-4}','k_{ci}=10^{-3}',...
    'location','northwest','Box','off')
axis([10,10000,0 100])
set(gca,'FontSize',18)
title('The effect of dimer-Notch affinity')
xlabel('Production rate of intracellular ligand (b_L)')
ylabel('Notch activity (NICD)')
set(gca, 'XScale', 'log')
