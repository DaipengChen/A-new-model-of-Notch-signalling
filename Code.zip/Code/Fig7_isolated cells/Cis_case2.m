% This code is for simulating the notch acitivity with different expression
% level of internal ligands.
% Written by Daipeng Chen (26 July, 2021)

clc
clear
close all

%% Parameter setting
D0=200;kd=1*10^(-4);beta=0.1; %DLL4 monomer in cell
kt=5*10^(-6);kc=6*10^(-4); %trans-activation and cis-inhibition
r=0.5; %degradation rate of signaling of Notch and VEGF
N0=200; %production of Notch
par=[D0 kd beta kc 0 kt r N0];

%% Initial condition
W0=unifrnd(0,100,1,4); %initial value of ODE
L=1000; %calculating period
size=2; %dimer

%% Solving ODE by Runge-Kutta solver
p=logspace(0,4,50);kca=[5*10^(-6) 4*10^(-6) 3*10^(-6) 2*10^(-6) 1*10^(-6)];
for j=1:length(p)
    par(1)=p(j);
    for i=1:5
        par(6)=kca(i);
        [~,W]=ode45(@GetCis,0:1:L,W0,[],par,size);
        X(i,j)=W(end,4);
    end
end

%% Output results
plot(p,X(1,:),'LineWidth',3,'Color',[0.6,0,0.6])
hold on
plot(p,X(2,:),'LineWidth',2,'Color',[0.8,0.8,0.8])
hold on
plot(p,X(3,:),'LineWidth',2,'Color',[0.6,0.6,0.6])
hold on
plot(p,X(4,:),'LineWidth',2,'Color',[0.4,0.4,0.4])
hold on
plot(p,X(5,:),'LineWidth',3,'Color',[0,0,0])
legend('k_{ca}=5*10^{-6}','k_{ca}=4*10^{-6}','k_{ca}=3*10^{-6}','k_{ca}=2*10^{-6}',...
    'k_{ca}=1*10^{-6}','location','northwest','Box','off')
axis([1,10000,0 6])
set(gca,'FontSize',18)
title('scenario 2')
xlabel('Production rate of intracellular ligand (b_L)')
ylabel('Notch activity (NICD)')
set(gca, 'XScale', 'log')

