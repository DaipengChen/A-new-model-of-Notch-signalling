function dF=GetODEs(~,w,par,Lext)

% parmeters
D0=par(1);kd=par(2);beta=par(3);kt=par(4);k3=par(5);
k4=par(6);r=par(7);N0=par(8);

%ode system
dF=[D0-beta*w(1)-2*kd*w(1)^2-k3*w(3)*w(1);
    kd*w(1)^2-k4*w(3)*w(2)-beta*w(2);
    N0-beta*w(3)-k3*w(1)*w(3)-k4*w(2)*w(3)-kt*Lext*w(3);
    kt*Lext*w(3)-r*w(4)];

end