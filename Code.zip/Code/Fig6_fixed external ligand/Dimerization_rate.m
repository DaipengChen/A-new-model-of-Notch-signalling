% This code is for simulating the notch acitivity with different expression
% level of internal ligands.
% Written by Daipeng Chen (26 July, 2021)

clc
clear
close all

%% Parameter setting
D0=2500;kd=1*10^(-4);beta=0.1; %DLL4 monomer in cell
kt=5*10^(-5);kc=6*10^(-4); %trans-activation and cis-inhibition
r=0.5; %degradation rate of signaling of Notch and VEGF
N0=200; %production of Notch
par=[D0 kd beta kt kc kc r N0];
Lext=1500;

%% Initial condition
L=2000; %calculating period
p=logspace(-8,-4,30);

%% Solving ODE by Runge-Kutta solver
for k = 1:length(p)
    par(2)= p(k);
    par(5)=0;par(6)=kc;
    [~,W1]=ode45(@GetODEs,0:1:L,unifrnd(0,100,1,4),[],par,Lext);
    par(5)=kc;par(6)=0;
    [~,W2]=ode45(@GetODEs,0:1:L,unifrnd(0,100,1,4),[],par,Lext);
    par(5)=kc;par(6)=kc;
    [~,W3]=ode45(@GetODEs,0:1:L,unifrnd(0,100,1,4),[],par,Lext);
    out1(k)=W1(end,4);
    out2(k)=W2(end,4);
    out3(k)=W3(end,4);
end

%% Output results
plot(p,out1,'LineWidth',3,'Color',[0.3,0.52,0.74])
hold on
plot(p,out2,'LineWidth',3,'Color',[0.97,0.56,0.24])
hold on
plot(p,out3,'LineWidth',3,'Color',[0.35,0.66,0.35])
set(gca, 'XScale', 'log')
title('High level of cis-ligand (L_0=2500)');
legend('Model C1','Model C2','Model C3');
xlabel('Cis-ligand dimerization rate (k_d)')
ylabel('Notch activity (NICD)')
set(gca,'FontSize',18)
