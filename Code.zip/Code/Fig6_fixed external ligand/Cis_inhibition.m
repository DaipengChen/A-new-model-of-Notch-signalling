% This code is for simulating the notch acitivity with different expression
% level of internal ligands.
% Written by Daipeng Chen (26 July, 2021)

clc
clear
close all

%% Parameter setting
D0=200;kd=1*10^(-4);beta=0.1; %DLL4 monomer in cell
kt=5*10^(-5);kc=6*10^(-4); %trans-activation and cis-inhibition
r=0.5; %degradation rate of signaling of Notch and VEGF
N0=200; %production of Notch
par=[D0 kd beta kt kc kc r N0];
Lext=1500;

%% Initial condition
L=2000; %calculating period

%% Solving ODE by Runge-Kutta solver
for k = 1:101
    p1(k)=25*(k-1);
    par(1)= p1(k);
    par(5)=0;par(6)=kc;
    [~,W1]=ode45(@GetODEs,0:1:L,unifrnd(0,100,1,4),[],par,Lext);
    par(5)=kc;par(6)=0;
    [~,W2]=ode45(@GetODEs,0:1:L,unifrnd(0,100,1,4),[],par,Lext);
    par(5)=kc;par(6)=kc;
    [~,W3]=ode45(@GetODEs,0:1:L,unifrnd(0,100,1,4),[],par,Lext);
    out1(k)=W1(end,4);
    out2(k)=W2(end,4);
    out3(k)=W3(end,4);
end

%% Output results
plot(p1,out1,'LineWidth',3,'Color',[0.3,0.52,0.74])
hold on
plot(p1,out2,'LineWidth',3,'Color',[0.97,0.56,0.24])
hold on
plot(p1,out3,'LineWidth',3,'Color',[0.35,0.66,0.35])
axis([0 2500 0 200]);
title('Cis-inhibition');
legend('Model C1','Model C2','Model C3');
xlabel('Production rate of cis-ligand (b_L)')
ylabel('Notch activity (NICD)')
set(gca,'FontSize',18)
