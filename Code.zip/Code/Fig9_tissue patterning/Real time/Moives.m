clc
clear
close all
gif2avi('cells_DV.gif')