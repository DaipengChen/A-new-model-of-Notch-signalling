function dF=GetODEs_vein(~,w,par,num,M,D)

% parmeters
L0=par(1);kd=par(2);beta=par(3);kt=par(4);
kc=par(5);r=par(6);N0=par(7);

% ode system
for i=1:num
    dF(4*i-3:4*i,:)=...
      [L0/exp(D(i)/1)-beta*w(4*i-3)-2*kd*w(4*i-3)^2-kt*M(i,:)*w(3:4:4*num)*w(4*i-3);
      kd*w(4*i-3)^2-kc*w(4*i-1)*w(4*i-2)-beta*w(4*i-2);
      N0-beta*w(4*i-1)-kc*w(4*i-2)*w(4*i-1)-kt*M(i,:)*w(1:4:4*num)*w(4*i-1);
      kt*M(i,:)*w(1:4:4*num)*w(4*i-1)-r*w(4*i)];
end

end