% this code is used to study the vein formation mediated by Notch
% Written by Daipeng Chen (26 July, 2022)
clc
clear
close all

%% Parameters
D0=15000;kd=1*10^(-4);beta=0.1; %DLL4 monomer in cell %%%D0=0.3-0.5!!!!?
kt=5*10^(-5);kc=6*10^(-4); %trans-activation and cis-inhibition
r=0.5; %degradation rate of signaling of Notch and VEGF
N0=200; %production of Notch
par=[D0 kd beta kt kc r N0];

%% Initial condition
m=11;n=22;num=m*n; % cell numbers
L=20; % calculate period at one step
W0=zeros(1,4*num); %initial values
W1=unifrnd(0,100,1,4*num); %initial values

%% Calculation
D=Distance_cells(m,n);
M=GetContactMatrix(m,n);
[~,Y1]=ode45(@GetODEs_vein,0:0.02:L,W0,[],par,num,M,D);

[~,Y2]=ode45(@GetODEs_vein,0:0.02:L,W1,[],par,num,M,D);
    
%% Output figures
for i=1:length(Y2(:,1))
    Notch1=Y1(i,4:4:end);
    Notch2=Y2(i,4:4:end);
    OutputVein(m,n,Notch1,Notch2)
    mov(i) = getframe;
    disp(i);
end

movie2gif(mov,'cells_vein.gif','LoopCount',0,'DelayTime',0.1);

