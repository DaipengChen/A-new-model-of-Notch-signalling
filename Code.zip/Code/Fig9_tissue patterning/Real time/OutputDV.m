function OutputDV(m,n,Notch1,Notch2)

close all
t=-pi/2:pi/3:3*pi/2;
x=sin(t);y=cos(t);

subplot(1,2,1)
s=1;
for i=1:m
    for j=1:n
        xp=x+3*(j-1)/2;
        yp=y+sqrt(3)*(i-1)+((-1)^j+1)*sqrt(3)/4;
        sf=Notch1(s)^5/(Notch1(s)^5+100^5);
        col=[sf sf/2+0.5 0.4];
        fill(xp(1:6),yp(1:6),col);
        hold on
        s=s+1;
    end
end
axis([-1 20.5 -0.9 38.1])
text(4.5,18,'D','Color','white','FontSize',19)
text(13,18,'V','Color','white','FontSize',19)
text(-2,-2,'Homogeneous initial state','FontSize',13);
axis off

subplot(1,2,2)
s=1;
for i=1:m
    for j=1:n
        xp=x+3*(j-1)/2;
        yp=y+sqrt(3)*(i-1)+((-1)^j+1)*sqrt(3)/4;
        sf=Notch2(s)^5/(Notch2(s)^5+100^5);
        col=[sf sf/2+0.5 0.4];
        fill(xp(1:6),yp(1:6),col);
        hold on
        s=s+1;
    end
end
axis([-1 20.5 -0.9 38.1])
text(4.5,18,'D','Color','white','FontSize',19)
text(13,18,'V','Color','white','FontSize',19)
text(-2,-2,'Heterogeneous initial state','FontSize',13);
axis off

pause(1)

end