% this code is used to study the boundary formation mediated by Notch
% Written by Daipeng Chen (26 July, 2022)
clc
clear
close all

%% Parameters
D0=200;kd=1*10^(-4);beta=0.1; %DLL4 monomer in cell %%%D0=0.3-0.5!!!!?
kt=5*10^(-5);kc=6*10^(-4); %trans-activation and cis-inhibition
r=0.5; %degradation rate of signaling of Notch and VEGF
N0=1000; %production of Notch
par=[D0 kd beta kt kc r N0];

%% Initial condition
m=22;n=14;num=m*n; % cell numbers
L=15; % calculate period at one step
W0=zeros(1,5*num); %initial values
W1=unifrnd(0,200,1,5*num); %initial values

%% Calculation
D=Distance_H(m,n);
M=GetContactMatrix(m,n);
[~,Y1]=ode45(@LD_dorsalventral,0:0.015:L,W0,[],par,num,M,D);

[~,Y2]=ode45(@LD_dorsalventral,0:0.015:L,W1,[],par,num,M,D);
    
%% Output figures
for i=1:length(Y2(:,1))
    Notch1=Y1(i,5:5:end);
    Notch2=Y2(i,5:5:end);
    OutputDV(m,n,Notch1,Notch2)
    mov(i) = getframe;
    disp(i);
end

movie2gif(mov,'cells_DV.gif','LoopCount',0,'DelayTime',0.1);

