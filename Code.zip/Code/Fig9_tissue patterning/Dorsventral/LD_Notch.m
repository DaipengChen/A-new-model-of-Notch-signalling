% this code is used to study the boundary formation mediated by Notch
% Written by Daipeng Chen (26 July, 2022)
clc
clear
close all

%% Parameters
D0=200;kd=1*10^(-4);beta=0.1; %DLL4 monomer in cell %%%D0=0.3-0.5!!!!?
kt=5*10^(-5);kc=6*10^(-4); %trans-activation and cis-inhibition
r=0.5; %degradation rate of signaling of Notch and VEGF
N0=200; %production of Notch
par=[D0 kd beta kt kc r N0];

%% Initial condition
m=4;n=24;num=m*n; % cell numbers
L=1500; % calculate period
W0=unifrnd(0,100,1,5*num); %initial values
p=logspace(2,4,20);

%% Calculation
D=Distance_H(m,n);
M=GetContactMatrix(m,n);
for i=1:length(p)
    par(end)=p(i);
    [~,Y]=ode45(@LD_dorsalventral,0:1:L,W0,[],par,num,M,D);
    Notch(i,:)=Y(end,5:5:5*n);
end
sf=Notch.^4./(Notch.^4+150^4);

%% Output figures
contourf(sf,'LineColor','none')
hold on
plot([12.5,12.5],[1,20],'--b','linewidth',3);
text(4,5,'Dorsal','Color','white','FontSize',19)
text(16,5,'Ventral','Color','white','FontSize',19)
yticks([4 8 12 16 20])
yticklabels({'10^{2.4}','10^{2.8}','10^{3.2}','10^{3.6}','10^{4.0}'})
xlabel('Horizontal position of cells')
ylabel('Production rate of Notch (b_N)')
set(gca,'xtick',[]);
set(gca,'FontSize',18)
colormap(summer);
