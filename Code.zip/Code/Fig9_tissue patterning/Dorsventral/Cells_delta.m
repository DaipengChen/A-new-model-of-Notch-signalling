% this code is used to study the boundary formation mediated by Notch
% Written by Daipeng Chen (26 July, 2022)
clc
clear
close all

%% Parameters
D0=200;kd=1*10^(-4);beta=0.1; %DLL4 monomer in cell %%%D0=0.3-0.5!!!!?
kt=5*10^(-5);kc=6*10^(-4); %trans-activation and cis-inhibition
r=0.5; %degradation rate of signaling of Notch and VEGF
N0=1000; %production of Notch
par=[D0 kd beta kt kc r N0];

%% Initial condition
t=-pi/2:pi/3:3*pi/2;
x=sin(t);y=cos(t);
m=15;n=18;num=m*n; % cell numbers
L=1500; % calculate period
W0=unifrnd(0,100,1,5*num); %initial values
Lmax=15000; %max production rate of ligands at H direction

%% Calculation
% protein production
H=Distance_H(m,n);
V=Distance_V(m,n);
for k=1:2*m
    P(k)=sqrt(3)*(k-1)/2;
    W1(k)=Lmax/exp(abs(P(k)-(sqrt(3)*m-sqrt(3)/2)/2));
end
% Notch activity
M=GetContactMatrix(m,n);
[~,Y]=ode45(@GetODEs_delta,0:1:L,W0,[],par,num,M,H,V,Lmax);
Notch=Y(end,5:5:end);

%% Output figures
subplot('position',[0.05 0.1 0.6 0.83])
s=1;
for i=1:m
    for j=1:n
        xp=x+3*(j-1)/2;
        yp=y+sqrt(3)*(i-1)+((-1)^j+1)*sqrt(3)/4;
        sf=Notch(s)^4/(Notch(s)^4+150^4);
        col=[sf sf/2+0.5 0.4];
        fill(xp(1:6),yp(1:6),col);
        hold on
        s=s+1;
    end
end
axis([-1 26.5 -0.9 26])
set(gca,'FontSize',18)
text(2,2,'Dorsal','Color','white','FontSize',19)
text(17,2,'Ventral','Color','white','FontSize',19)
text(1.0,-2.5,'Horizontal position of cells','FontSize',19)
axis off

subplot('position',[0.67 0.1 0.23 0.83])
plot(W1,P,'-.m','LineWidth',2)
text(300,6.7,'Delta','Color','M','FontSize',19)
text(100,-2,'0','Color','k','FontSize',19)
text(7000,-2,'10^{4}','Color','k','FontSize',19)
axis([0 10000 -0.5 26])
set(gca,'xtick',[]);
set(gca,'ytick',[]);
set(gca,'FontSize',18)
box on

