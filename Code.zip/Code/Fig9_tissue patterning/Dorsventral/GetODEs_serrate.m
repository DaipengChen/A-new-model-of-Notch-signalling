function dF=GetODEs_serrate(~,w,par,num,M,H,V,Lmax)

% parmeters
L0=par(1);kd=par(2);beta=par(3);kt=par(4);
kc=par(5);r=par(6);N0=par(7);

% ode system
for i=1:num
    if H(i)<0 %dorsal cells
        dF(5*i-4:5*i,:)=...
            [L0+Lmax/exp(V(i))-beta*w(5*i-4)-2*kd*w(5*i-4)^2;
            0-beta*w(5*i-3)-2*kd*w(5*i-3)^2-kt*M(i,:)*w(4:5:5*num)*w(5*i-3);
            kd*w(5*i-4)^2+kd*w(5*i-3)^2-kc*w(5*i-1)*w(5*i-2)-beta*w(5*i-2);
            N0-beta*w(5*i-1)-kc*w(5*i-2)*w(5*i-1)-kt*M(i,:)*w(2:5:5*num)*w(5*i-1);
            kt*M(i,:)*w(2:5:5*num)*w(5*i-1)-r*w(5*i)];
    else     %ventral cells
        dF(5*i-4:5*i,:)=...
            [Lmax/exp(V(i))-beta*w(5*i-4)-2*kd*w(5*i-4)^2-kt*M(i,:)*w(4:5:5*num)*w(5*i-4);
            L0-beta*w(5*i-3)-2*kd*w(5*i-3)^2;
            kd*w(5*i-4)^2+kd*w(5*i-3)^2-kc*w(5*i-1)*w(5*i-2)-beta*w(5*i-2);
            N0-beta*w(5*i-1)-kc*w(5*i-2)*w(5*i-1)-kt*M(i,:)*w(1:5:5*num)*w(5*i-1);
            kt*M(i,:)*w(1:5:5*num)*w(5*i-1)-r*w(5*i)];
    end
end

end