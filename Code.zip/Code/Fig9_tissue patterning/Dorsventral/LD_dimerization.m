% this code is used to study the boundary formation mediated by Notch
% Written by Daipeng Chen (26 July, 2022)
clc
clear
close all

%% Parameters
D0=200;kd=1*10^(-4);beta=0.1; %DLL4 monomer in cell %%%D0=0.3-0.5!!!!?
kt=5*10^(-5);kc=6*10^(-4); %trans-activation and cis-inhibition
r=0.5; %degradation rate of signaling of Notch and VEGF
N0=1000; %production of Notch
par=[D0 kd beta kt kc r N0];

%% Initial condition
t=-pi/2:pi/3:3*pi/2;
x=sin(t);y=cos(t);
m=15;n=6;num=m*n; % cell numbers
L=1500; % calculate period
W0=unifrnd(0,100,1,5*num); %initial values
Lmax=15000; %max production rate of ligands at H direction
p=logspace(-6,-4,20); %dimerization rate

%% Calculation
H=Distance_H(m,n);
V=Distance_V(m,n);
M=GetContactMatrix(m,n);
for i=1:length(p)
    p0=p(i);
    [~,Y]=ode45(@GetODEs_dimer,0:1:L,W0,[],par,num,M,H,V,Lmax,p0);
    Notch1=Y(end,5:5*n:end); %the first col
    Notch2=Y(end,10:5*n:end); %the second col
    rand=[Notch1;Notch2];
    Notch(i,:)=rand(:)';
end
sf=Notch.^4./(Notch.^4+150^4);

%% Output figures
contourf(sf,'LineColor','none')
yticks([4 8 12 16 20])
yticklabels({'10^{-5.6}','10^{-5.2}','10^{-4.8}','10^{-4.4}','10^{-4.0}'})
xlabel('Vertical position of cells')
ylabel('Ligands dimerization rate (k_d)')
set(gca,'xtick',[]);
set(gca,'FontSize',18)
colormap(summer);
view(90,-90);
