% this code is used to study the boundary formation mediated by Notch
% Written by Daipeng Chen (26 July, 2022)
clc
clear
close all

%% Parameters
D0=200;kd=1*10^(-4);beta=0.1; %DLL4 monomer in cell %%%D0=0.3-0.5!!!!?
kt=5*10^(-5);kc=6*10^(-4); %trans-activation and cis-inhibition
r=0.5; %degradation rate of signaling of Notch and VEGF
N0=1000; %production of Notch
par=[D0 kd beta kt kc r N0];

%% Initial condition
t=-pi/2:pi/3:3*pi/2;
x=sin(t);y=cos(t);
m=15;n=26;num=m*n; % cell numbers
L=1500; % calculate period
W0=unifrnd(0,100,1,5*num); %initial values

%% Calculation
D=Distance_H(m,n);
M=GetContactMatrix(m,n);
[~,Y]=ode45(@LD_dorsalventral,0:1:L,W0,[],par,num,M,D);
Notch=Y(end,5:5:end);

%% Output figures
subplot('position',[0.05 0.1 0.85 0.8])
s=1;
for i=1:m
    for j=1:n
        xp=x+3*(j-1)/2;
        yp=y+sqrt(3)*(i-1)+((-1)^j+1)*sqrt(3)/4;
        sf=Notch(s)^4/(Notch(s)^4+150^4);
        col=[sf sf/2+0.5 0.4];
        fill(xp(1:6),yp(1:6),col);
        hold on
        s=s+1;
    end
end
axis([-1 38.5 -0.9 26])
title('Ligands dimerization model');
set(gca,'FontSize',18)
text(5,5,'Dorsal','Color','white','FontSize',19)
text(26,5,'Ventral','Color','white','FontSize',19)
text(7,-2.5,'Horizontal position of cells','FontSize',19)
axis off

