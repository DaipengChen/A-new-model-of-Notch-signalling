function D=Distance_H(m,n)
num=m*n;
D=zeros(num,1);
t=-pi/2:pi/3:3*pi/2;
X0=3*(n-1)/4;
for i=1:m
    for j=1:n
        X=3*(j-1)/2;
        k=n*(i-1)+j;
        D(k)=X-X0;
    end
end
end