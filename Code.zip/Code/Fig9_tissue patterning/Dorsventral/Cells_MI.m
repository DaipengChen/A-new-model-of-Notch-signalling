% this code is used to study the boundary formation mediated by Notch
% Written by Daipeng Chen (26 July, 2022)
clc
clear
close all

%% Parameters
D0=200;kd=1*10^(-4);beta=0.1; %DLL4 monomer in cell %%%D0=0.3-0.5!!!!?
kt=5*10^(-5);kc=6*10^(-4); %trans-activation and cis-inhibition
r=0.5; %degradation rate of signaling of Notch and VEGF
N0=1000; %production of Notch
par=[D0 kd beta kt kc r N0];

%% Initial condition
t=-pi/2:pi/3:3*pi/2;
x=sin(t);y=cos(t);
m=7;n=24;num=m*n; % cell numbers
L=1500; % calculate period
W0=unifrnd(0,100,1,4*num); %initial values

%% Calculation
D=Distance_H(m,n);
M=GetContactMatrix(m,n);
[~,Y]=ode45(@MI_dorsalventral,0:1:L,W0,[],par,num,M,D);
Notch=Y(end,4:4:end);

%% Output figures
t=tiledlayout(2,1);                                    %Requires R2019b or later
nexttile
line([0 3*(n-1)/4],[D0 D0],'Color','r','LineStyle','-.','LineWidth',2)
hold on
line([3*(n-1)/4 3*(n-1)/2],[D0 D0],'Color','m','LineStyle','-.','LineWidth',2)
hold on
line([0 3*(n-1)/2],[N0 N0],'Color','b','LineStyle','-.','LineWidth',2)
text(1,350,'Serrate','FontSize',19,'color','r')
text(28,350,'Delta','FontSize',19,'color','m')
text(14,2000,'Notch','FontSize',19,'color','b')
title('Mutual inactivation model')
ylabel('Production rate')
axis([-1 35.5 100 10000])
set(gca,'FontSize',18)
set(gca, 'YScale', 'log')
box on

nexttile
s=1;
for i=1:m
    for j=1:n
        xp=x+3*(j-1)/2;
        yp=y+sqrt(3)*(i-1)+((-1)^j+1)*sqrt(3)/4;
        sf=Notch(s)^4/(Notch(s)^4+150^4);
        col=[sf sf/2+0.5 0.4];
        fill(xp(1:6),yp(1:6),col);
        hold on
        s=s+1;
    end
end
axis([-1 35.5 -0.9 12.2])
text(-6.5,-1.3,'Notch activity','FontSize',19,'rotation',90)
text(5,6,'Dorsal','Color','white','FontSize',19)
text(23,6,'Ventral','Color','white','FontSize',19)
text(4.2,-3.0,'Horizontal position of cells','FontSize',19)
colormap(summer);
colorbar('color','none','position',[0.1 0.1 0.04 0.36]);
axis off
t.TileSpacing='compact';

