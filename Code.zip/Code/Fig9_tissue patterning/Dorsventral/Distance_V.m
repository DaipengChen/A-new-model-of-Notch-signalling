function D=Distance_V(m,n)
num=m*n;
D=zeros(num,1);
t=-pi/2:pi/3:3*pi/2;
x0=cos(t);
X0=(sqrt(3)*m-sqrt(3)/2)/2;
for i=1:m
    for j=1:n
        x=x0+sqrt(3)*(i-1)+((-1)^j+1)*sqrt(3)/4;
        X=mean(x(1:6));
        k=n*(i-1)+j;
        D(k)=sqrt((X-X0).^2);
    end
end
end