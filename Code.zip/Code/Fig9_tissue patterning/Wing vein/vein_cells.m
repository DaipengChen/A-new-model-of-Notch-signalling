% this code is used to study the vein formation mediated by Notch
% Written by Daipeng Chen (26 July, 2022)
clc
clear
close all

%% Parameters
D0=15000;kd=1*10^(-4);beta=0.1; %DLL4 monomer in cell %%%D0=0.3-0.5!!!!?
kt=5*10^(-5);kc=6*10^(-4); %trans-activation and cis-inhibition
r=0.5; %degradation rate of signaling of Notch and VEGF
N0=200; %production of Notch
par=[D0 kd beta kt kc r N0];

%% Initial condition
t=-pi/2:pi/3:3*pi/2;
x=sin(t);y=cos(t);
m=11;n=22;num=m*n; % cell numbers
L=100; % calculate period
W0=unifrnd(0,100,1,4*num); %initial values

%% Calculation
% protein production
D=Distance_cells(m,n);
for k=1:n
    P(k)=3*(k-1)/2;
    W1(k)=D0/exp(D(k)/1);
    W2(k)=N0;
end
% Notch activity
M=GetContactMatrix(m,n);
[~,Y]=ode45(@GetODEs_vein,0:0.1:L,W0,[],par,num,M,D);
Notch=Y(end,4:4:end);

%% Output figures
t=tiledlayout(1,2);                                    %Requires R2019b or later
nexttile
s=1;
for i=1:m
    for j=1:n
        xp=x+3*(j-1)/2;
        yp=y+sqrt(3)*(i-1)+((-1)^j+1)*sqrt(3)/4;
        sf=Notch(s)^5/(Notch(s)^5+50^5);
        col=[sf sf/2+0.5 0.4];
        fill(xp(1:6),yp(1:6),col);
        hold on
        s=s+1;
    end
end
axis([-1 32.5 -0.9 19.1])
text(1,-5,'Vertical position of cells','FontSize',19,'rotation',90)
text(5,4.8,'Posterior','Color','white','FontSize',19)
text(16,7,'Vein','Color','white','FontSize',19)
text(27,5,'Anterior','Color','white','FontSize',19)
text(-8.2,1.5,'Notch activity','FontSize',19)
text(-2.6,0,'low','FontSize',19)
text(-2.6,13,'high','FontSize',19)
colormap(summer);
colorbar('southoutside','color','none','position',[0.12 0.1 0.36 0.04]);
axis off
t.TileSpacing='compact';
view(90,-90)

nexttile
plot(P,W1,'-.m','LineWidth',2)
hold on
plot(P,W2,'-.b','LineWidth',2)
text(30,230,'Notch','FontSize',19,'color','b')
text(5.2,1.5,'Delta','FontSize',19,'color','m')
ylabel('Production rate')
axis([-1 32.5 1 10000])
set(gca,'FontSize',18)
set(gca, 'YScale', 'log')
view(90,-90)


